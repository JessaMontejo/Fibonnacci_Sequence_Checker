import 'dart:io';
bool fibcheck(List<int> fiblist) {
  for (int i = 2; i<fiblist.length; i++)
  { if((fiblist[i - 1] + fiblist[i - 2]) != fiblist[i])
    {return false;}
  }
  return true;
  }

void main() {
	print('Checking Fibbonacci\n');

  List<int> fiblist = new List();
  print("Enter the size of the list (the size must be greater than 3 or less than 10):");

  int size = int.parse(stdin.readLineSync());

  if(size < 3 || size > 10) {
    print("Invalid number size");
    }
    else {
      for(int i = 0; i < size; i++){
        int a = i+1;
        print("Enter the desired number $a: ");
        
        fiblist.add(int.parse(stdin.readLineSync()));
        }
        print(fiblist);
        print(fibcheck(fiblist));
        }
}