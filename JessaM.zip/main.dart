import 'dart:io';

void main() {
	var numb = 1;
  double lead = 45.75;
  double unlead = 43.18;
  double die = 37.12;
  double bio_die = 48.03;
  var total;

  print("Choose a number only: ");
  print("1. Cash");
  print("2. Liter");

  var choose = int.parse(stdin.readLineSync());
  if (numb == choose) {
    print("Cash has been chosen\n");}
  else {
    print("Liter has been chosen\n");}
    
    print("What type of fuel?");

    print("1: Leaded");
    print("2: Unleaded");
    print("3: Diesel");
    print("4: Bio-Diesel");

    var fuel = int.parse(stdin.readLineSync());
    if (fuel == 1) {
      print("Price of Leaded fuel: 45.75");}
    else if (fuel == 2) {
      print("Price of Unleaded fuel: 43.18");}
    else if (fuel == 3) {
      print("Price of Diesel fuel: 37.12");}
    else if (fuel == 4){
      print("Price of Bio-diesel fuel: 48.03");}
    else {
      print("Out of option");}

    print("How many liters?");
    var liter = int.parse(stdin.readLineSync());

    print("Money you have?");
    var money = int.parse(stdin.readLineSync());

    if (fuel == 1) {
      var total_lead = lead * liter;
      print("$liter Liter");
      print("Total: $total_lead");
      if (total_lead > money) {
        print("Money not enough");}
      var change = money - total_lead;
      print("Change: $change");}

    else if (fuel == 2) {
      var total_unlead = unlead * liter;
      print("$liter Liters");
      print("Total Amount: $total_unlead");
      if (total_unlead > money) {
        print("Money not enough");}
      var change_unlead = money - total_unlead;
      print("Change: $change_unlead");}

    else if (fuel == 3) {
      var total_die = die * liter;
      print("$liter Liters");
      print("Total Amount: $total_die");
      if (total_die > money) {
        print("Money not enough");}
      var change_die = money - total_die;
      print("Change: $change_die");}

    else if (fuel == 4) {
      var total_bio = bio_die * liter;
      print("$liter Liters");
      print("Total Amount: $total_bio");
      if (total_bio > money) {
        print("Money not enough");}
      var change_bio = money - total_bio;
      print("Change: $change_bio");}

    else {
      print("Not available");} 

}